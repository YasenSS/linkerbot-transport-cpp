# Transport 0.3.4 压测报告

## 一、Ubuntu 系统压测

### 测试信息

测试时间：2026-11-10T14:45:57.475125+08:00 至 2026-11-10T15:24:31.648066+08:00。
状态：正式流程完成，四项无损确认有效。共 119 档，失败 6 档，失败档不计入无损成绩。

系统：PRETTY_NAME="Ubuntu 25.10"
NAME="Ubuntu"
VERSION_ID="25.10"
VERSION="25.10 (Questing Quokka)"
VERSION_CODENAME=questing
ID=ubuntu
ID_LIKE=debian
HOME_URL="https://www.ubuntu.com/"
SUPPORT_URL="https://help.ubuntu.com/"
BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
UBUNTU_CODENAME=questing
LOGO=ubuntu-logo。
内核：6.17.0-41-generic；逻辑核：16。

```text
Architecture:                            x86_64
CPU op-mode(s):                          32-bit, 64-bit
Address sizes:                           48 bits physical, 48 bits virtual
Byte Order:                              Little Endian
CPU(s):                                  16
On-line CPU(s) list:                     0-15
Vendor ID:                               AuthenticAMD
Model name:                              AMD Ryzen 7 H 260 w/ Radeon 780M Graphics
CPU family:                              25
Model:                                   117
Thread(s) per core:                      2
Core(s) per socket:                      8
Socket(s):                               1
Stepping:                                2
Frequency boost:                         enabled
CPU(s) scaling MHz:                      45%
CPU max MHz:                             5102.7129
CPU min MHz:                             416.5480
BogoMIPS:                                7586.13
Flags:                                   fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca cmov pat pse36 clflush mmx fxsr sse sse2 ht syscall nx mmxext fxsr_opt pdpe1gb rdtscp lm constant_tsc rep_good amd_lbr_v2 nopl xtopology nonstop_tsc cpuid extd_apicid aperfmperf rapl pni pclmulqdq monitor ssse3 fma cx16 sse4_1 sse4_2 x2apic movbe popcnt aes xsave avx f16c rdrand lahf_lm cmp_legacy svm extapic cr8_legacy abm sse4a misalignsse 3dnowprefetch osvw ibs skinit wdt tce topoext perfctr_core perfctr_nb bpext perfctr_llc mwaitx cpuid_fault cpb cat_l3 cdp_l3 hw_pstate ssbd mba perfmon_v2 ibrs ibpb stibp ibrs_enhanced vmmcall fsgsbase bmi1 avx2 smep bmi2 erms invpcid cqm rdt_a avx512f avx512dq rdseed adx smap avx512ifma clflushopt clwb avx512cd sha_ni avx512bw avx512vl xsaveopt xsavec xgetbv1 xsaves cqm_llc cqm_occup_llc cqm_mbm_total cqm_mbm_local user_shstk avx512_bf16 clzero irperf xsaveerptr rdpru wbnoinvd cppc arat npt lbrv svm_lock nrip_save tsc_scale vmcb_clean flushbyasid decodeassists pausefilter pfthreshold vgif x2avic v_spec_ctrl vnmi avx512vbmi umip pku ospke avx512_vbmi2 gfni vaes vpclmulqdq avx512_vnni avx512_bitalg avx512_vpopcntdq rdpid overflow_recov succor smca fsrm flush_l1d amd_lbr_pmc_freeze
Virtualization:                          AMD-V
L1d cache:                               256 KiB (8 instances)
L1i cache:                               256 KiB (8 instances)
L2 cache:                                8 MiB (8 instances)
L3 cache:                                16 MiB (1 instance)
NUMA node(s):                            1
NUMA node0 CPU(s):                       0-15
Vulnerability Gather data sampling:      Not affected
Vulnerability Ghostwrite:                Not affected
Vulnerability Indirect target selection: Not affected
Vulnerability Itlb multihit:             Not affected
Vulnerability L1tf:                      Not affected
Vulnerability Mds:                       Not affected
Vulnerability Meltdown:                  Not affected
Vulnerability Mmio stale data:           Not affected
Vulnerability Old microcode:             Not affected
Vulnerability Reg file data sampling:    Not affected
Vulnerability Retbleed:                  Not affected
Vulnerability Spec rstack overflow:      Mitigation; Safe RET
Vulnerability Spec store bypass:         Mitigation; Speculative Store Bypass disabled via prctl
Vulnerability Spectre v1:                Mitigation; usercopy/swapgs barriers and __user pointer sanitization
Vulnerability Spectre v2:                Mitigation; Enhanced / Automatic IBRS; IBPB conditional; STIBP always-on; PBRSB-eIBRS Not affected; BHI Not affected
Vulnerability Srbds:                     Not affected
Vulnerability Tsa:                       Mitigation; Clear CPU buffers
Vulnerability Tsx async abort:           Not affected
Vulnerability Vmscape:                   Mitigation; IBPB before exit to userspace
```

编译器：c++ (Ubuntu 15.2.0-4ubuntu4) 15.2.0。Release（CMake 默认 -O3 -DNDEBUG），C++17；库自身测试、示例、基准及依赖下载均关闭。

源码目录：`/home/linkerhand/test_SDk/linkerbot-transport-cpp`；版本：`0.3.4`。
提交：`0e190032d65ed0b315337b45b3779cf4f650ed68`。工作树：干净。
源码 SHA256 指纹：`2b390a4adc521fc8d1d8f83451daf07b8a9f67b5da65de5bc56d9a0d78277597`；测试期间源码保持一致。
实际链接库：`/tmp/lbt-stress-12j7m84q/build/local-library/liblinkerbot-can.a`，SHA256：`08fccdf516ad91137d1eb0dd6d18a7448a10fd2d8697e64b675fa4cd13aae52a`。静态库、链接映射、compile_commands.json、CMakeCache.txt 和构建日志均在原始数据包中。

### 压测方式

直接编译所选本地源码，不拉取远程、不使用发布包；每次在新的临时目录构建。内存回环与独立网络命名空间内 vcan 各测经典 CAN 8 字节、CAN FD+BRS 64 字节。
发送线程为 1/2/4/8/16/32，每批 1/8 帧、初始窗口 8 批；补测 1/8 线程、每批 32/128 帧、窗口 1 批，再调整最快候选窗口为 1/4/16/32 批（总在途不超过 4096 帧、1024 批）。每档筛选 15 秒，最快两个无损配置各复测 30 秒，择优连续两次确认 60 秒；若失败则尝试第二候选。
每线程提交窗口内各批，等发送凭据完成并按序收到所有回复后继续。校验 ID、帧标志、长度、序号及负载模式；以正确回复数量÷实际运行秒数计吞吐，一次请求与一次回复只计一次完整收发。经典 CAN 的 8 字节全部为序号及时间戳；FD 其余 56 字节也逐字节校验。
正常 vcan 吞吐两端均申请 4 MiB 接收缓冲，只改变本次 socket。另测默认缓冲区 8 线程×8 帧×8 批过载，扩大缓冲和缩小窗口的对照；相同在途量比较线程数，并以相同 FD 配置比较逐帧、批量模拟端。
P99 为 10µs 直方图桶上界（末桶使用实际最大值）。CPU 100% 表示一个逻辑核，包含压测程序、通信库和模拟端的进程 CPU，内核开销计入 system；RSS 为整个进程。软件回环成绩不代表物理 CAN 带宽。

### 测试结果

- **内存回环经典 CAN：**两次确认 **113.58 / 113.51 万次完整收发/秒**；8 线程，每批 128 帧，每线程窗口 4 批，总在途上限 4096 帧。校验数量 **68150272 / 68111360**；P99 **4.249 / 4.289 ms**；CPU **2.31 / 2.31 核**；RSS 采样范围 **7.36～7.64 MiB**；库内溢出 **0 / 0**；内核丢帧 **不适用（未经过内核 socket）**。原始记录：`020-confirm-memory-can-t8-b128-w4`、`021-confirm-memory-can-t8-b128-w4`。
- **内存回环 CAN FD：**两次确认 **128.85 / 127.73 万次完整收发/秒**；1 线程，每批 128 帧，每线程窗口 16 批，总在途上限 2048 帧。校验数量 **77314048 / 76638208**；P99 **1.909 / 1.919 ms**；CPU **2.03 / 2.03 核**；RSS 采样范围 **5.97～6.10 MiB**；库内溢出 **0 / 0**；内核丢帧 **不适用（未经过内核 socket）**。原始记录：`080-confirm-memory-fd-t1-b128-w16`、`081-confirm-memory-fd-t1-b128-w16`。
- **vcan 经典 CAN：**两次确认 **33.06 / 33.37 万次完整收发/秒**；8 线程，每批 8 帧，每线程窗口 8 批，总在途上限 512 帧。校验数量 **19838848 / 20024256**；P99 **2.009 / 2.029 ms**；CPU **3.59 / 3.61 核**；RSS 采样范围 **5.96～6.01 MiB**；库内溢出 **0 / 0**；内核丢帧 **Session 0 / 0，模拟端 0 / 0**。原始记录：`045-confirm-vcan-can-t8-b8-w8`、`046-confirm-vcan-can-t8-b8-w8`。
- **vcan CAN FD：**两次确认 **32.58 / 32.65 万次完整收发/秒**；8 线程，每批 32 帧，每线程窗口 1 批，总在途上限 256 帧。校验数量 **19548352 / 19591904**；P99 **0.979 / 0.959 ms**；CPU **3.29 / 3.28 核**；RSS 采样范围 **5.88～6.04 MiB**；库内溢出 **0 / 0**；内核丢帧 **Session 0 / 0，模拟端 0 / 0**。原始记录：`103-confirm-vcan-fd-t8-b32-w1`、`104-confirm-vcan-fd-t8-b32-w1`。

实际 socket 接收缓冲（内核返回值，可能为申请值的两倍）：
- vcan 经典 CAN：session=8388608 B/peer=8388608 B；session=8388608 B/peer=8388608 B。
- vcan CAN FD：session=8388608 B/peer=8388608 B；session=8388608 B/peer=8388608 B。

### 性能分析

#### 1. 高并发下丢帧

- 经典 CAN `047-overload-vcan-can-t8-b8-w8`：失败；8×8×8，default 缓冲（session=212992 B, peer=212992 B）；提交/库发/模拟收/模拟回/库收/校验=1408/1408/1331/1331/1331/1262；内核丢帧 Session=0、模拟端=77；库内溢出=0。
- 经典 CAN `048-overload-vcan-can-t8-b8-w8`：失败；8×8×8，default 缓冲（session=212992 B, peer=212992 B）；提交/库发/模拟收/模拟回/库收/校验=3648/3648/3640/3640/3640/3572；内核丢帧 Session=0、模拟端=8；库内溢出=0。
- 经典 CAN `049-overload-vcan-can-t8-b8-w8`：失败；8×8×8，default 缓冲（session=212992 B, peer=212992 B）；提交/库发/模拟收/模拟回/库收/校验=5696/5696/5674/5674/5674/5593；内核丢帧 Session=0、模拟端=22；库内溢出=0。
- 经典 CAN `050-buffer-control-vcan-can-t8-b8-w8`：通过；8×8×8，large 缓冲（session=8388608 B, peer=8388608 B）；提交/库发/模拟收/模拟回/库收/校验=9973888/9973888/9973888/9973888/9973888/9973888；内核丢帧 Session=0、模拟端=0；库内溢出=0。
- 经典 CAN `051-window-control-vcan-can-t8-b8-w1`：通过；8×8×1，default 缓冲（session=212992 B, peer=212992 B）；提交/库发/模拟收/模拟回/库收/校验=4894744/4894744/4894744/4894744/4894744/4894744；内核丢帧 Session=0、模拟端=0；库内溢出=0。

经典 CAN：本轮内核计数确认 模拟回复接收端 的 socket 接收队列发生丢帧。扩大缓冲及减少在途量两项对照均通过，支持突发接收队列过载的解释。这些过载记录未见库内溢出。

- CAN FD `105-overload-vcan-fd-t8-b8-w8`：失败；8×8×8，default 缓冲（session=212992 B, peer=212992 B）；提交/库发/模拟收/模拟回/库收/校验=3776/3776/3711/3711/3711/3450；内核丢帧 Session=0、模拟端=65；库内溢出=0。
- CAN FD `106-overload-vcan-fd-t8-b8-w8`：失败；8×8×8，default 缓冲（session=212992 B, peer=212992 B）；提交/库发/模拟收/模拟回/库收/校验=1856/1856/1831/1831/1815/1686；内核丢帧 Session=16、模拟端=25；库内溢出=0。
- CAN FD `107-overload-vcan-fd-t8-b8-w8`：失败；8×8×8，default 缓冲（session=212992 B, peer=212992 B）；提交/库发/模拟收/模拟回/库收/校验=1472/1472/1472/1472/1447/1367；内核丢帧 Session=25、模拟端=0；库内溢出=0。
- CAN FD `108-buffer-control-vcan-fd-t8-b8-w8`：通过；8×8×8，large 缓冲（session=8388608 B, peer=8388608 B）；提交/库发/模拟收/模拟回/库收/校验=9763648/9763648/9763648/9763648/9763648/9763648；内核丢帧 Session=0、模拟端=0；库内溢出=0。
- CAN FD `109-window-control-vcan-fd-t8-b8-w1`：通过；8×8×1，default 缓冲（session=212992 B, peer=212992 B）；提交/库发/模拟收/模拟回/库收/校验=4938600/4938600/4938600/4938600/4938600/4938600；内核丢帧 Session=0、模拟端=0；库内溢出=0。

CAN FD：本轮内核计数确认 模拟回复接收端、Session 接收端 的 socket 接收队列发生丢帧。扩大缓冲及减少在途量两项对照均通过，支持突发接收队列过载的解释。这些过载记录未见库内溢出。

#### 2. 性能瓶颈

- 经典 CAN：2 线程×8 帧×8 批，128 帧在途上限，2 次有效对照；平均 32.83 万次/秒，平均 P99 0.539 ms，CPU 3.49 核，模拟端 CPU 0.99 核。
- 经典 CAN：8 线程×8 帧×2 批，128 帧在途上限，2 次有效对照；平均 32.99 万次/秒，平均 P99 0.509 ms，CPU 3.64 核，模拟端 CPU 0.99 核。
- 经典 CAN：8 线程×8 帧×8 批，512 帧在途上限，2 次有效对照；平均 33.33 万次/秒，平均 P99 1.989 ms，CPU 3.64 核，模拟端 CPU 0.99 核。

经典 CAN：相同 128 帧在途上限时，2→8 线程吞吐变化 +0.5%；8 线程将上限从 128→512 帧时，吞吐变化 +1.0%，平均 P99 从 0.509→1.989 ms。差异受调度与运行波动影响，只支持本次配置间比较。

- CAN FD：2 线程×8 帧×8 批，128 帧在途上限，2 次有效对照；平均 32.92 万次/秒，平均 P99 0.529 ms，CPU 3.51 核，模拟端 CPU 0.99 核。
- CAN FD：8 线程×8 帧×2 批，128 帧在途上限，2 次有效对照；平均 33.27 万次/秒，平均 P99 0.504 ms，CPU 3.66 核，模拟端 CPU 0.99 核。
- CAN FD：8 线程×8 帧×8 批，512 帧在途上限，2 次有效对照；平均 33.59 万次/秒，平均 P99 2.009 ms，CPU 3.64 核，模拟端 CPU 0.99 核。

CAN FD：相同 128 帧在途上限时，2→8 线程吞吐变化 +1.1%；8 线程将上限从 128→512 帧时，吞吐变化 +1.0%，平均 P99 从 0.504→2.009 ms。差异受调度与运行波动影响，只支持本次配置间比较。

- FD 相同 2×8×8、大缓冲配置，库模拟端逐帧：32.79 万次/秒，P99 0.549 ms，模拟端 CPU 0.99 核（`116-peer-comparison-vcan-fd-t2-b8-w8`）。
- FD 相同 2×8×8、大缓冲配置，原始 socket 模拟端逐帧：35.15 万次/秒，P99 0.489 ms，模拟端 CPU 0.99 核（`117-peer-comparison-vcan-fd-t2-b8-w8`）。
- FD 相同 2×8×8、大缓冲配置，原始 socket 模拟端批量 32 帧：39.72 万次/秒，P99 0.419 ms，模拟端 CPU 0.98 核（`118-peer-comparison-vcan-fd-t2-b8-w8`）。

仅将原始 socket 模拟端从逐帧改为批量后，本轮吞吐变化 +13.0%；说明测试端实现影响观测吞吐。
本次没有单函数或锁的剖析证据，不能确定唯一瓶颈，也不能把有限参数搜索的最高成绩视为通信库的绝对上限。RSS 仅表示本次有限时长内的观测，不能证明长期无泄漏。

### 失败配置与完整性

- `047-overload-vcan-can-t8-b8-w8`：退出码 1；压测校验未通过或 JSON 缺失；peer 内核丢帧 77。原始 stdout/日志：`047-overload-vcan-can-t8-b8-w8.json` / `047-overload-vcan-can-t8-b8-w8.log`。
- `048-overload-vcan-can-t8-b8-w8`：退出码 1；压测校验未通过或 JSON 缺失；peer 内核丢帧 8。原始 stdout/日志：`048-overload-vcan-can-t8-b8-w8.json` / `048-overload-vcan-can-t8-b8-w8.log`。
- `049-overload-vcan-can-t8-b8-w8`：退出码 1；压测校验未通过或 JSON 缺失；peer 内核丢帧 22。原始 stdout/日志：`049-overload-vcan-can-t8-b8-w8.json` / `049-overload-vcan-can-t8-b8-w8.log`。
- `105-overload-vcan-fd-t8-b8-w8`：退出码 1；压测校验未通过或 JSON 缺失；peer 内核丢帧 65。原始 stdout/日志：`105-overload-vcan-fd-t8-b8-w8.json` / `105-overload-vcan-fd-t8-b8-w8.log`。
- `106-overload-vcan-fd-t8-b8-w8`：退出码 1；压测校验未通过或 JSON 缺失；session 内核丢帧 16；peer 内核丢帧 25。原始 stdout/日志：`106-overload-vcan-fd-t8-b8-w8.json` / `106-overload-vcan-fd-t8-b8-w8.log`。
- `107-overload-vcan-fd-t8-b8-w8`：退出码 1；压测校验未通过或 JSON 缺失；session 内核丢帧 25。原始 stdout/日志：`107-overload-vcan-fd-t8-b8-w8.json` / `107-overload-vcan-fd-t8-b8-w8.log`。

原始数据见同目录 `压测原始数据.tar.gz`。压缩包包含本报告副本、逐档 JSON/CSV/日志、socket 计数、运行环境、源码指纹、工具源码、编译参数和实际链接库。归档文件逐项 SHA256 校验后才清理临时目录。
