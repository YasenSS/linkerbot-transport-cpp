# 本地通信库 Ubuntu 压测工具

```bash
python3 stress/run.py --quick          # 先快速验证，非正式成绩
python3 stress/run.py                  # 正式全流程，约 40 分钟
python3 stress/run.py --source /path/to/linkerbot-transport-cpp
python3 stress/run.py --verify 压测原始数据.tar.gz
```

默认测试相邻 `linkerbot-transport-cpp/` 的实际源码，不联网同步、不使用 `releases/` 包。使用 Python 3.10+、CMake、GCC/G++、Git、iproute2、kmod，以及可免交互执行 `ip netns`、`modprobe vcan`、`kill` 的 `sudo -n`。仅支持 Ubuntu；需要 vcan 内核支持，无需物理 CAN 设备。

每次在新临时目录构建 Release，链接 `linkerbot::can`。库自身测试、示例、基准、串口/Modbus和依赖下载关闭，不改公共 API。实际库版本、HEAD、工作树、源码 SHA256 清单、编译命令、链接映射及库摘要存入原始包；构建后与测试后再次核对源码指纹，变化即标记无效。源码为 Git 工作树，可带本地变更，报告会明确记录。

正式扫描：内存/vcan × CAN 8 字节/FD+BRS 64 字节；1/2/4/8/16/32 线程×1/8 帧×8 批，补测 1/8 线程×32/128 帧×1 批，调整最快候选窗口 1/4/16/32 批。每档 15 秒，最快两档复测 30 秒，择优连续两次确认 60 秒。失败配置单列并剔除。正常 vcan 两端申请 4 MiB 缓冲，记录实际值及 socket 内核丢帧。还执行边界/恢复契约、默认缓冲过载与对照、相同在途量线程对照、FD 模拟端逐帧/批量对照。

`throughput_worker.cpp` 负责吞吐和逐帧验证；`profile_worker.cpp` 负责队列、CPU 和模拟端对照；`socket_probe.c` 只在 CAN socket 打开/关闭时采集内核统计、调整本次接收缓冲，不拦截逐帧读写。`run.py` 编排、清理并由本次记录生成报告。CPU/RSS 包含模拟端，软件链路成绩不代表物理带宽。

正式运行仅输出 `压测报告.md`、`压测原始数据.tar.gz`；快速验证使用 `快速验证报告.md`、`快速验证原始数据.tar.gz`，不覆盖正式成绩。可用 `--output DIR` 指定输出目录。编译产物、逐档 JSON/CSV/日志均在临时目录，归档逐文件 SHA256 和报告数值一致性校验完成后删除。包内保留构建产物以复核链接来源，路径中的临时目录测试后不存在是正常的。

只创建本次独立网络命名空间内的 vcan，不触碰物理接口或全局 sysctl。正常、超时、异常和 SIGINT/SIGTERM 都停止本次进程组、清理命名空间并归档现有证据；错误返回非零，报告标记不完整。无法捕获 SIGKILL/断电，发生后可按终端打印的本次命名空间名称手工检查。归档失败不会宣称报告成功。

工具自检：`PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s stress -p 'test_*.py'`。`raspberry_pi/` 为保留的历史独立工具，不属于本 Ubuntu 流程。迁移前旧 Ubuntu 工具已归档至 `archives/stress-tools-before-migration-20261110.tar.gz`。
